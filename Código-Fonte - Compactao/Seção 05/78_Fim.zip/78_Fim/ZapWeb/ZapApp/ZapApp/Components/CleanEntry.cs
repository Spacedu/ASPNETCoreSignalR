﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace ZapApp.Components
{
    public class CleanEntry : Entry
    {
    }
}
